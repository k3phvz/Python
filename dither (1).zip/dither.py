import sys
import matplotlib.pyplot as plt

# On charge l'image à réduire et on la convertit en liste de pixels
img = plt.imread("./test.jpg").tolist()

# Couleurs que l'algorithme pourra utiliser pour "approximer" la valeur d'un pixel
COLORS = [
    [0, 0, 0],            # Noir
    [255, 255, 255],      # Blanc
    [255, 0, 0],          # Rouge
    [0, 255, 0],          # Vert
    [0, 0, 255],          # Bleu
]

# Convertit une valeur numérique à virgule en un nombre entier compris entre 0 et 255
# Les valeurs RGB que nous utilisons doivent être comprises entre ces deux valeurs
def to_byte(n):
    return max(0, min(255, int(round(n, 0))))

# Fonction calculant la distance entre chaque couleurs d'un pixel A et un pixel B
def pixel_error(pixel_a, pixel_b):
    r_error = pixel_b[0] - pixel_a[0]
    g_error = pixel_b[1] - pixel_a[1]
    b_error = pixel_b[2] - pixel_a[2]
    return [r_error, g_error, b_error]

# Fonction qui choisit dans la liste des couleurs COLORS, la couleur qui est la plus
# proche de celle du pixel passé en paramètre
# Pour cela, on calcule l'erreur totale entre ce pixel et chaque couleur de la palette,
# et on prends la plus petite
def find_closest_color(pixel):
    errors = [(n, pixel_error(pixel, try_pixel)) for (n, try_pixel) in enumerate(COLORS)]
    best = sorted(errors, key=lambda p: sum([err**2 for err in p[1]]))
    return COLORS[best[0][0]]

# Affiche le résultat
def show(grid):
    plt.gca().invert_yaxis()
    plt.imshow(grid)
    plt.show()
    sys.exit(0)


###### Début du TP ######



