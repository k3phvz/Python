#!/usr/bin/env python3

import os
import time
import random
import platform

def random_boolean(prob):
    return random.random() <= prob

def to_string(game_of_life):
    s = "┌" + ("─" * (game_of_life.width * 2)) + "┐\n"
    for y in range(game_of_life.height):
        s += "│"
        for x in range(game_of_life.width):
            if game_of_life.grid[y][x]:
                s += "▓▓"
            else:
                s += "  "
        s += "│\n"
    s += "└" + ("─" * (game_of_life.width * 2)) + "┘\n"
    return s

def play(obj):
    is_windows = platform.system() == "Windows"
    print(to_string(obj))
    input("Press Enter to start")
    while True:
        if is_windows:
            os.system("cls")
        else:
            os.system("clear")

        print(to_string(obj))
        gol.update()
        time.sleep(0.05)
